from utility import *

#ltautomation@gmail.com
#ltapi@ltapi.com

BASE_URL="https://captivateprimestage1.adobe.com/primeapi/v1/learner-transcripts"


# get request decorator
def get_request_LT(func):
    global cred
    global l
    global data
    global BASE_URL
    global token_url
    def wrapper(*args):
        url=BASE_URL
        Access_Token=get_New_Token(token_url,cred)
        hdr={"Authorization":"oauth "+Access_Token["access_token"]}
        print(url)
        print(data)
        res=get(url,params=data,headers=hdr)
        return func(res.json(),res.status_code)
    return wrapper


#################################### WRAPPER FUNCTION #############################################################################

@get_request_LT
def get_LT_COURSE_response_codebody(*args):
   return args[0],args[1]


@get_request_LT
def get_LT_LP_response_codebody(*args):
   return args[0],args[1]


@get_request_LT
def get_LT_CER_response_codebody(*args):
   return args[0],args[1]


##########################################  DATA PULLING CODE ################################################################
def get_LT_course_response():
    global data
    data.clear()
    data["lo_type"]="Course"
    data["page[offset]"]=0
    data["page[limit]"]=100
    res,code=get_LT_COURSE_response_codebody()
    if code!=200:
       raise Exception
    return res


def get_LT_LP_response():
    global data
    data.clear()
    data["lo_type"]="LearningProgram"
    data["page[offset]"]=0
    data["page[limit]"]=100
    res,code=get_LT_LP_response_codebody()
    if code!=200:
       raise Exception
    return res


def get_LT_Certificate_response():
    global data
    data.clear()
    data["lo_type"]=""
    data["page[offset]"]=0
    data["page[limit]"]=100
    res,code=get_LT_CER_response_codebody()
    if code!=200:
        raise Exception
    return res

############################################ VALIDATION CODE #################################################################


@Report_generate
def  test_userCourseModuleDetail_date(Testcase,res,userid,courseid,moduleid,datestarted,datecompleted,*keys):
   try:
      key_module=[]
      for key in res["data"]["userCourseModuleDetails"][str(userid)][str(courseid)][str(moduleid)].keys():
         key_module.append(key)
      for k in keys:
         if k not in key_module:
           return False   
      for key in res["data"]["userCourseModuleDetails"][str(userid)][str(courseid)][str(moduleid)].keys():
         if key=="dateStarted":
            if  res["data"]["userCourseModuleDetails"][str(userid)][str(courseid)][str(moduleid)][key]!=datestarted:
               return False
         elif key=="dateCompleted":
            if  res["data"]["userCourseModuleDetails"][str(userid)][str(courseid)][str(moduleid)][key]!=datecompleted:
               return False
      return True
   except Exception as e:
      return False



@Report_generate
def  test_userCourseModuleDetail_score(Testcase,res,userid,courseid,moduleid,rawscore,highscore,scoremax,*keys):
   try:
      key_module=[]
      for key in res["data"]["userCourseModuleDetails"][str(userid)][str(courseid)][str(moduleid)].keys():
         key_module.append(key)
      for k in keys:
         if k not in key_module:
           return False   
      for key in res["data"]["userCourseModuleDetails"][str(userid)][str(courseid)][str(moduleid)].keys():
         if key=="scoreRaw":
            if res["data"]["userCourseModuleDetails"][str(userid)][str(courseid)][str(moduleid)][key]!=rawscore:
               return False
         elif key=="highestScoreRaw":
            if  res["data"]["userCourseModuleDetails"][str(userid)][str(courseid)][str(moduleid)][key]!=highscore:
               return False
         elif key=="scoreMax":
            if  res["data"]["userCourseModuleDetails"][str(userid)][str(courseid)][str(moduleid)][key]!=scoremax:
               return False
      return True
   except Exception as e:
      return False


@Report_generate
def  test_userCourseModuleDetail_progress(Testcase,res,userid,courseid,moduleid,grade,status,progress,*keys):
   try:
      key_module=[]
      for key in res["data"]["userCourseModuleDetails"][str(userid)][str(courseid)][str(moduleid)].keys():
         key_module.append(key)
      for k in keys:
         if k not in key_module:
           return False   
      for key in res["data"]["userCourseModuleDetails"][str(userid)][str(courseid)][str(moduleid)].keys():
         if key=="status":
            if res["data"]["userCourseModuleDetails"][str(userid)][str(courseid)][str(moduleid)][key]!=status:
               return False
         elif key=="progress":
            if  res["data"]["userCourseModuleDetails"][str(userid)][str(courseid)][str(moduleid)][key]!=progress:
               return False
         elif key=="grade":
            if  res["data"]["userCourseModuleDetails"][str(userid)][str(courseid)][str(moduleid)][key]!=grade:
               return False
      return True
   except Exception as e:
      return False	


@Report_generate
def  test_userCourseDetail_progress(Testcase,res,userid,courseid,grade,status,progress,*keys):
   try:
      key_course=[]
      for key in res["data"]["userCourseDetails"][str(userid)][str(courseid)].keys():
         key_course.append(key)
      for k in keys:
         if k not in key_course:
           return False   
      for key in res["data"]["userCourseDetails"][str(userid)][str(courseid)].keys():
         if key=="status":
            if res["data"]["userCourseDetails"][str(userid)][str(courseid)][key]!=status:
               return False
         elif key=="progress":
            if  res["data"]["userCourseDetails"][str(userid)][str(courseid)][key]!=progress:
               return False
         elif key=="grade":
            if  res["data"]["userCourseDetails"][str(userid)][str(courseid)][key]!=grade:
               return False
      return True
   except Exception as e:
      return False

@Report_generate
def  test_userCourseDetail_score(Testcase,res,userid,courseid,rawscore,highscore,scoremax,*keys):
   try:
      key_course=[]
      for key in res["data"]["userCourseDetails"][str(userid)][str(courseid)].keys():
         key_course.append(key)
      for k in keys:
         if k not in key_course:
           return False   
      for key in res["data"]["userCourseDetails"][str(userid)][str(courseid)].keys():
         if key=="scoreRaw":
            if res["data"]["userCourseDetails"][str(userid)][str(courseid)][key]!=rawscore:
               return False
         elif key=="highestScoreRaw":
            if  res["data"]["userCourseDetails"][str(userid)][str(courseid)][key]!=highscore:
               return False
         elif key=="scoreMax":
            if  res["data"]["userCourseDetails"][str(userid)][str(courseid)][key]!=scoremax:
               return False
      return True
   except Exception as e:
      return False



@Report_generate
def  test_userCourseDetail_date(Testcase,res,userid,courseid,dateenrolled,datestarted,datecompleted,deadline,*keys):
   try:
      key_course=[]
      for key in res["data"]["userCourseDetails"][str(userid)][str(courseid)].keys():
         key_course.append(key)
      for k in keys:
         if k not in key_course:
           return False   
      for key in res["data"]["userCourseDetails"][str(userid)][str(courseid)].keys():
         if key=="dateEnrolled":
            if res["data"]["userCourseDetails"][str(userid)][str(courseid)][key]!=dateenrolled:
               return False
         elif key=="dateStarted":
            if  res["data"]["userCourseDetails"][str(userid)][str(courseid)][key]!=datestarted:
               return False
         elif key=="dateCompleted":
            if  res["data"]["userCourseDetails"][str(userid)][str(courseid)][key]!=datecompleted:
               return False
         elif key=="deadline":
            if  res["data"]["userCourseDetails"][str(userid)][str(courseid)][key]!=deadline:
               return False
      return True
   except Exception as e:
      return False
   
@Report_generate
def  test_user_Coursedetails(Testcase,res,*lpid):
   try:
      course_id=[]
      for id in res["data"]["courseDetails"].keys():
          course_id.append(id)
      for id in lpid:
          if id not in course_id:
              return False
      return True
   except Exception as e:
      return False


@Report_generate
def  test_user_LPName(Testcase,res,lpname,*lpid):
   try:
      lp_name=[]
      for id in lpid:
         for obj in res["data"]["lpDetails"][str(id)]:
             lp_name.append(obj["name"])
      for name in lpname:
         if name not in lp_name:
             return False
      return True
   except Exception as e:
      return False


############################################# VALIDATION  FUNCTION LT api(LP) ##############################################
if __name__=="__main__":
   Auto_init("LT_DELETE_Course.csv")
   Env_init("9ced40ef-0f43-4177-83ba-2c9c9b168077","6d3dfc50-7113-4de8-966a-84b0d0915d3d","669d022db52608dcb828a4af007bc6d2")
   res=get_LT_course_response()
   test_user_Coursedetails("Verify the courseid's in LT api response for Course",res,"3039256","3039254","3039252","3039253")

   #####################################  USER COURSE DETAIL ###############################################################

   test_userCourseDetail_date("Verify the user Course detail date",res,"7272641","3039253","2020-03-04T06:56:00.000Z","2020-03-04T08:56:00.000Z","2020-03-05T06:02:00.000Z","2020-12-29T06:56:00.000Z","dateEnrolled","dateStarted","dateCompleted","deadline")
   test_userCourseDetail_score("Verify the user Course detail score",res,"7272641","3039253",60,60,60,"scoreRaw","highestScoreRaw","scoreMax")
   test_userCourseDetail_progress("Verify the user progress detail for course",res,"7272641","3039253","Pass","Completed",100,"status","progress","grade")

   #####################################   USER MODULE DETAIL #############################################################

   test_userCourseModuleDetail_date("Verify the dates realated to usermodule details",res,"7272641","3039254","3678928","2020-03-04T07:01:00.000Z","2020-03-04T07:02:00.000Z","dateStarted","dateCompleted")
   test_userCourseModuleDetail_score("Verify the score related to usermodule details",res,"7272641","3039254","3678928",60,60,60,"scoreRaw","highestScoreRaw","scoreMax")
   test_userCourseModuleDetail_progress("Verify the progress related to usermodule details",res,"7272641","3039254","3678928","Pass","Completed",100,"status","progress","grade")
   Auto_close()





















