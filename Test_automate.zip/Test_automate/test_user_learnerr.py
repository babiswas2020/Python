from utility import *
from time import time
import json
from random import randint

#ftpconnectioncheck+80@gmail.com


#learner_user body

learner_user={
  "data": {
    "id": "5628120",
    "type": "user",
    "attributes": {
      "bio": "Hello this is me 80  meeee\n",
      "contentLocale": "en-US",
      "email": "ftpconnectioncheck+80@gmail.com",
      "fields": {
        "Abbb": "b"
      },
      "lastLoginDate": "2019-05-10T12:03:35.000Z",
      "metadata": {
        "value233": "e",
        "value344": "f",
        "valuerrrrrrr": "tyjjjjjjjj"
      },
      "name": "ftpconnectioncheck80 changed 1234",
      "profile": "senior consultant",
      "timeZoneCode": "356",
      "uiLocale": "en-US",
      "userType": "Internal"
    },
    "relationships": {
      "account": {
        "data": {
          "id": "4846",
          "type": "account"
        }
      },
      "manager": {
        "data": {
          "id": "5628119",
          "type": "user"
        }
      }
    }
  }
}

#learner user body.

learner_local={
  "data": {
    "id": "5628120",
    "type": "user",
    "attributes": {
      "bio": "Hello this is me 80  meeee\n",
      "contentLocale": "fr-FR",
      "fields": {
        "Abbb": "b"
      },
      "lastLoginDate": "2019-05-10T10:27:37.000Z",
      "metadata": {
        "value233": "e",
        "value344": "f",
        "valuerrrrrrr": "tyjjjjjjjj"
      },
      "timeZoneCode": "356",
      "uiLocale": "fr-FR",
      "userType": "Internal"
    }
  }
}

########################################################## JSON MODIFIER #########################################################################

def json_modifier_id(id):
    global learner_user
    learner_user["data"]["id"]=str(id)


def json_modifier():
    global learner_user
    learner_user["data"]["attributes"]["bio"]="Hello this is me 80"
    learner_user["data"]["attributes"]["contentLocale"]="fr-FR"
    learner_user["data"]["attributes"]["metadata"]["value"+str(2)]="Hello"+str(time())
    learner_user["data"]["attributes"]["timeZoneCode"]="356"
    learner_user["data"]["attributes"]["fields"]["Abbb"]="a"

def json_modifier_default():
    global learner_user
    learner_user["data"]["attributes"]["bio"]="Hello this is me 90"
    learner_user["data"]["attributes"]["contentLocale"]="fr-FR"
    learner_user["data"]["attributes"]["metadata"]["value3"]="HelloDefault"
    learner_user["data"]["attributes"]["timeZoneCode"]="356"
    learner_user["data"]["attributes"]["fields"]["Abbb"]="b"

def json_modifier_update():
    global learner_user
    learner_user["data"]["attributes"]["bio"]="Hello this is me 80 Updated"
    learner_user["data"]["attributes"]["contentLocale"]="en-US"
    learner_user["data"]["attributes"]["metadata"]["value3"]="HelloDefault Hi"
    learner_user["data"]["attributes"]["timeZoneCode"]="187"
    learner_user["data"]["attributes"]["fields"]["Abbb"]="a"

def json_modifier_bio(bio):
    global learner_user
    learner_user["data"]["attributes"]["bio"]=bio


def json_modifier_contentlocale(locale):
    global learner_user
    learner_user["data"]["attributes"]["contentLocale"]=locale

def json_modifier_metadata(value):
    global learner_user
    learner_user["data"]["attributes"]["metadata"]["value5"]=value


def json_modifier_timezone(timezone):
    global learner_user
    learner_user["data"]["attributes"]["timeZoneCode"]=timezone


def json_modifier_fields(fields):
    global learner_user
    learner_user["data"]["attributes"]["fields"]["Abbb"]=fields

def json_modifier_uilocale(uilocale):
    global learner_user
    learner_user["data"]["attributes"]["uiLocale"]=uilocale

######################################################################### REQUST DECORATOR ###########################################################


#POST request function for testing basic functionality of POST method
@post_request_payload
def post_user(*args):
      return args[3]

#POST request function for getting the response body of the post method.
@post_request_payload
def post_get_user_body(*args):
      return args[2]

#GET request function to retrieve the user by id.
@get_request
def get_user_by_id(*args):
    return args[2]

#GET request function to get the response body.
@get_request
def get_userbody_by_id(*args):
    return args[1]

#PATCH request to test the basic functionality of the PATCH method.
@patch_request_payload
def patch_update_user(*args):
  return args[3]

#PATCH request function to test the PATCH api response body using GET.
@patch_request_payload
def patch_update_user_get_body(*args):
  return args[2]

#delete 
@delete_request_parameter
def  delete_user_by_id(*args):
    return args[1]


###################################################################### TEST CASE ########################################################################

#Testcase is the testcase string.
#id is the user id.
#Removed manager role along with current role.

@Report_generate
def  test_patch_update_learner_metadata_field(Testcase,id):
     json_modifier_id(id)
     str1="users/"+str(id)
     res=patch_update_user(str1,json.dumps(learner_user))
     if res==200:
       return True
     else:
       return False

#Testcase is the testcase string.
#id is the id of the user.
#testing the patch update for the learner.

@Report_generate
def  test_patch_update_learner_metadata_field_get_id(Testcase,id):
     json_modifier_id(id)
     str1="users/"+str(id)
     json_modifier_default()
     res=patch_update_user_get_body(str1,json.dumps(learner_user))
     res=get_userbody_by_id(str1)
     if res["data"]["attributes"]["metadata"]["value3"]=="HelloDefault" and res["data"]["attributes"]["fields"]["Abbb"]=="b":
           if res["data"]["attributes"]["contentLocale"]=="fr-FR" and res["data"]["attributes"]["timeZoneCode"]=="356":
               return True
           else:
               return False
     else:
           return False


#Testcase is the testcase string.
#id is the user id.
#testing the patch update for the learner.

@Report_generate
def  test_patch_update_learner_metadatachange_field_get_id(Testcase,id):
     json_modifier_id(id)
     str1="users/"+str(id)
     json_modifier_update()
     res=patch_update_user_get_body(str1,json.dumps(learner_user))
     print(res)
     res=get_userbody_by_id(str1)
     if res["data"]["attributes"]["metadata"]["value3"]=="HelloDefault Hi" and res["data"]["attributes"]["fields"]["Abbb"]=="a":
           if res["data"]["attributes"]["contentLocale"]=="en-US" and res["data"]["attributes"]["timeZoneCode"]=="187":
               return True
           else:
               return False
     else:
           return False


#Testcase is the testcase string.
#id is the user id of the user id.
#bio is the bio of the user.
#Testing the bio of the user.

@Report_generate
def  test_patch_update_learner_bio_get_id(Testcase,id,bio):
     json_modifier_id(id)
     str1="users/"+str(id)
     json_modifier_bio(bio)
     res=patch_update_user_get_body(str1,json.dumps(learner_user))
     res=get_userbody_by_id(str1)
     if res["data"]["attributes"]["bio"]==bio:
         return True
     else:
         return False


#Testcase is the testcase string 
#id is the user id.
#contentlocale is the contentlocale of the user.
#Testing the content locale of the user.

@Report_generate
def  test_patch_update_learner_contentlocale_get_id(Testcase,id,locale):
     json_modifier_id(id)
     str1="users/"+str(id)
     json_modifier_contentlocale(locale)
     res=patch_update_user_get_body(str1,json.dumps(learner_user))
     res=get_userbody_by_id(str1)
     if res["data"]["attributes"]["contentLocale"]==locale:
         return True
     else:
         return False


#Testcase is the testcase string.
#id is the id field of the user.
#timezone is the timezone field of the user.
#testing the timezone field of the user.

@Report_generate
def  test_patch_update_learner_timezone_get_id(Testcase,id,timezone):
     json_modifier_id(id)
     str1="users/"+str(id)
     json_modifier_timezone(timezone)
     res=patch_update_user_get_body(str1,json.dumps(learner_user))
     res=get_userbody_by_id(str1)
     if res["data"]["attributes"]["timeZoneCode"]==timezone:
         return True
     else:
         return False


#Testcase is the testcase string.
#id is the id field of the user.
#fields is the active field of the user.
#testing the active fields of the user.

@Report_generate
def  test_patch_update_learner_fields_get_id(Testcase,id,fields):
     json_modifier_id(id)
     str1="users/"+str(id)
     json_modifier_fields(fields)
     res=patch_update_user_get_body(str1,json.dumps(learner_user))
     res=get_userbody_by_id(str1)
     if res["data"]["attributes"]["fields"]["Abbb"]==fields:
         return True
     else:
         return False


#Testcase is the testcase string.
#id is the id of the user.
#uilocale is the uilocale for the user.
#testing the uilocale of the user.

@Report_generate
def  test_patch_update_learner_uilocale_get_id(Testcase,id,uilocale):
     json_modifier_id(id)
     str1="users/"+str(id)
     json_modifier_uilocale(uilocale)
     res=patch_update_user_get_body(str1,json.dumps(learner_user))
     res=get_userbody_by_id(str1)
     if res["data"]["attributes"]["uiLocale"]==uilocale:
         return True
     else:
         return False


#Testcase is the testcase string.
#id is the id of the user.
#Value is the value of the metadata.
#Testing the metadata value of the user.

@Report_generate
def  test_patch_update_learner_metadata_get_id(Testcase,id,value):
     json_modifier_id(id)
     str1="users/"+str(id)
     json_modifier_metadata(value)
     res=patch_update_user_get_body(str1,json.dumps(learner_user))
     res=get_userbody_by_id(str1)
     if res["data"]["attributes"]["metadata"]["value5"]==value:
         return True
     else:
         return False
    
########################################################################## TEST CASE EXECUTE ################################################################


if __name__=="__main__":
   Auto_init("User_learner.csv")
   Env_init("704bafcf-9296-4ca6-926d-8c02be3f8a98","028a8891-f8e1-4a3d-b61c-32c2d82c9264","3ad8efcca374427c081fae303c8a2dd8")
   #test_patch_update_learner_metadata_field("Test the basic functionality of learner PATCH update",)
   #test_patch_update_learner_metadata_field_get_id("Test the metadata/active field update of the user Active field value b",5628120)
   #test_patch_update_learner_metadatachange_field_get_id("Test the metadata/active fields  change the values retrieve using GET",5628120)
   test_patch_update_learner_bio_get_id("Test the learner bio update",6539488,"Hello Hello Hello")
   test_patch_update_learner_bio_get_id("Test the learner bio change for the user",6539488,"Dillo Dillo Dillo")
   test_patch_update_learner_contentlocale_get_id("Test the content locale for the user",6539488,"fr-FR")
   test_patch_update_learner_contentlocale_get_id("Test the content locale change for the user",6539488,"en-US")
   test_patch_update_learner_timezone_get_id("Test the timezone of the user",6539488,"356")
   test_patch_update_learner_timezone_get_id("Test the timezone change of the user",6539488,"187")
   #test_patch_update_learner_fields_get_id("Test the active fields value for the user",6539488,"a")
   #test_patch_update_learner_fields_get_id("Test the active fields value change for the user",6539488,"b")
   test_patch_update_learner_uilocale_get_id("Test the learner uilocale for the user",6539488,"fr-FR")
   test_patch_update_learner_uilocale_get_id("Test the learner uilocale change for the user",6539488,"en-US")
   #test_patch_update_learner_metadata_get_id("Test the metadata value for the user",6539488,"GRRRRRRRR")
   #test_patch_update_learner_metadata_get_id("Test the metadata value change for the user",6539488,"BRRRRRRRR")
   Auto_close()




