from url_generator import *
from requests import get, post
import sys


class Catalog:
    query = {"page[offset]": 0, "page[limit]": 10, "sort": "name", "ids": ''}
    endpoint = "catalogs"
    SORT = {"name", "-name","dateCreated","-dateCreated","dateUpdated","-dateUpdated"}
    hdr = {"Authorization": ''}
    URL = ""
    URL_ID = ""

    def __init__(self, no):
        self.no = no

        
    @property
    def set_url(self):
        return Catalog.URL

        
    @set_url.setter
    def set_url(self, base_url):
        Catalog.URL = base_url + Catalog.endpoint

        
    @property
    def set_url_id(self):
        return Catalog.URL_ID

        
    @set_url_id.setter
    def set_url_id(self,catalog_id):
        Catalog.URL_ID = Catalog.URL + "/" + str(badge_id)

        
    @property
    def set_query(self):
        return Catalog.query

        
    @set_query.setter
    def set_query(self, key):
        Catalog.query["page[offset]"] = str(key["offset"])
        Catalog.query["page[limit]"] = str(key["limit"])
        if key["sort"]=="name":
            Catalog.query["sort"] ="name"
        elif key["sort"]=="-name":
            Catalog.query["sort"] = "-name"
        elif key["sort"]=="dateCreated":
            Catalog.query["sort"] = "dateCreated"
        elif key["sort"]=="-name":
            Catalog.query["sort"] = "-dateCreated"
        elif key["sort"]=="dateUpdated":
            Catalog.query["sort"] = "dateUpdated"
        elif key["sort"]=="-dateUpdated":
            Catalog.query["sort"] = "-dateUpdated"
        else:
            Catalog.query["sort"]="name"
        try:
            if key["ids"]:
                 Catalog.query["ids"] = '%2C'.join(key["ids"])
        except Exception as e:
            pass
            if "ids" in Catalog.query:
                  del Catalog.query["ids"]

            
    @property
    def set_header(self):
        return Catalog.hdr


    @set_header.setter
    def set_header(self, *args):
        token = Catalog.generate_token()
        Catalog.hdr["Authorization"] = "oauth " + token["access_token"]

        
    @staticmethod
    def generate_token(base_url):
        global CRED
        global get_New_Token
        print(base_url.split('primeapi')[0])
        url = base_url.split('primeapi')[0]
        access_token = get_New_Token(url,CRED)
        Catalog.hdr["Authorization"] = "oauth " + access_token["access_token"]

    @classmethod
    def get_catalog_response_body(cls):
        res = get(Catalog.URL, params=Catalog.query, headers=Catalog.hdr)
        return res.json()


    @classmethod
    def get_catalog_response_code(cls):
        res = get(Catalog.URL, params=Catalog.query, headers=Catalog.hdr)
        return res.status_code

    def pagination_catalog(self,query,env,pagelimit,offset):
        global enviroment
        fail=False
        test=False
        has_next=True
        total_records_obtained=0


        Catalog.generate_token(enviroment[env])
        self.set_url=enviroment[env]

        if query=="name":
            self.set_query={"offset":str(offset),"limit":str(pagelimit),"sort":"name"}
        elif query=="-name":
            self.set_query={"offset":str(offset),"limit":str(pagelimit),"sort":"-name"}
        elif query=="dateCreated":
            self.set_query={"offset":str(offset),"limit":str(pagelimit),"sort":"dateCreated"}
        elif query=="-dateCreated":
            self.set_query={"offset":str(offset),"limit":str(pagelimit),"sort":"-dateCreated"}
        elif query=="dateUpdated":
            self.set_query={"offset":str(offset),"limit":str(pagelimit),"sort":"dateUpdated"}
        elif query=="-dateUpdated":
            self.set_query={"offset":str(offset),"limit":str(pagelimit),"sort":"-dateUpdated"}

        while not fail and has_next:
            try:
                res=Catalog.get_catalog_response_body()
                total_records_obtained=total_records_obtained+len(res["data"])
                if res["links"]["next"]:
                   print(res["links"]["next"].split('?')[1].split('&')[0])
                   Catalog.query["page[offset]"]=res["links"]["next"].split('?')[1].split('&')[0].split('=')[1]
                   has_next=True
                if len(res["data"])==pagelimit and has_next:
                    if total_records_obtained>self.no:
                        fail=True
                        test=False
                    else:
                        fail=False
                elif len(res["data"])<pagelimit and not has_next:
                    if total_records_obtained<self.no:
                        fail=True
                        test=False
                    elif total_records_obtained==self.no:
                        fail=True
                        test=True
                    elif total_records_obtained>self.no:
                        fail=True
                        test=False
                elif len(res["data"])>pagelimit:
                        fail=True
                        test=False
                elif len(res["data"])<pagelimit and has_next:
                        fail=True
                        test=False
                elif len(res["data"])==pagelimit and not has_next:
                        if total_records_obtained==self.no:
                            test=True
                        else:
                            test=False
                            fail=True
            except KeyError as k:
                if total_records_obtained==self.no:
                    fail=True
                    test=True
                    has_next=False
                else:
                    fail=True
                    test=False
                    has_next=False

        return test



if __name__ == "__main__":
    global enviroment
    print(enviroment[sys.argv[1]])
    Catalog.generate_token(enviroment[sys.argv[1]])
    catalog = Catalog(7)
    catalog.set_url = enviroment[sys.argv[1]]
    catalog.set_query = {"offset": 0, "limit": 10, "sort": "name"}
    print(Catalog.get_catalog_response_body())
    print(catalog.pagination_catalog("name",sys.argv[1],2,0))
    print(catalog.pagination_catalog("-name",sys.argv[1],2,0))
    print(catalog.pagination_catalog("dateCreated",sys.argv[1],2,0))
    print(catalog.pagination_catalog("-dateCreated",sys.argv[1],2,0))
    print(catalog.pagination_catalog("dateUpdated",sys.argv[1],2,0))
    print(catalog.pagination_catalog("-dateUpdated",sys.argv[1],2,0))



















