import sys
from requests import post,get
from contextlib import contextmanager

enviroment = {"QE": "https://captivateprimeqe.adobe.com/primeapi/v2/",
              "STAGE1": "https://captivateprimestage1.adobe.com/primeapi/v2/",
              "PROD": "https://captivateprime.adobe.com/primeapi/v2/"}

constants = {
    "userid": "",
    "badgeid": "",
    "userbadgeid": "",
    "catalogid": "",
    "skillid": ""
}

CRED = {"client_id": "0c4176c8-391f-40b0-849f-727a5e130678",
        "client_secret": "9c5b2608-ccca-4c42-b21e-2e0c3a795797", "refresh_token": "c6a320b20723f476bd9f82e304d6ac16"}


def Env_init(clientid, client_secret, refresh_token):
    global CRED
    CRED["client_id"] = str(clientid)
    CRED["client_secret"] = str(client_secret)
    CRED["refresh_token"] = str(refresh_token)


def get_New_Token(base_url, cred):
    global CRED
    header = {"Content-type": "application/x-www-form-urlencoded"}
    final_url = base_url + "oauth/token/refresh"
    print(final_url)
    print("hello")
    response = post(final_url,params=CRED, headers=header)
    print(response)
    data_json = response.json()
    print(data_json)
    return data_json

@contextmanager
def build_report(name):
    try:
        m=open(name,'w')
        yield m
    finally:
        if m:
          m.close()


def  ReportGenerate(params,*args):
    def wrapper(func):
        test=func(*args)
        params.writerow({'TestCase':args[0],'Verdict':str(test)})
    return wrapper


def get_base_url():
    return constants["userid"]


def get_user_id():
    return constants["userid"]


def get_badge_id():
    return constants["badgeid"]


def get_user_badge_id():
    return constants["userbadgeid"]


def get_catalog_id():
    return constants["catalogid"]


def get_skill_id():
    return constants["skillid"]




