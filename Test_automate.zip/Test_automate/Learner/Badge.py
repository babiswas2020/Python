from url_generator import *
from requests import get, post
import sys


class Badge:
    query = {"page[offset]": 0, "page[limit]": 10, "sort": "name", "ids": ''}
    endpoint = "badges"
    SORT = {"name", "-name"}
    hdr = {"Authorization": ''}
    URL = ""
    URL_ID = ""

    def __init__(self, no):
        self.no = no
    @property
    def set_url(self):
        return Badge.URL
    @set_url.setter
    def set_url(self, base_url):
        Badge.URL = base_url + Badge.endpoint
    @property
    def set_url_id(self):
        return Badge.URL_ID
    @set_url_id.setter
    def set_url_id(self, badge_id):
        Badge.URL_ID = Badge.URL + "/" + str(badge_id)
    @property
    def set_query(self):
        return Badge.query
    @set_query.setter
    def set_query(self, key):
        Badge.query["page[offset]"] = str(key["offset"])
        Badge.query["page[limit]"] = str(key["limit"])
        if key["sort"]=="name":
            Badge.query["sort"] = "name"
        else:
            Badge.query["sort"] = "-name"
        try:
            if key["ids"]:
                 Badge.query["ids"] = '%2C'.join(key["ids"])
        except Exception as e:
            pass
            if "ids" in Badge.query:
                  del Badge.query["ids"]
    @property
    def set_header(self):
        return Badge.hdr

    @set_header.setter
    def set_header(self, *args):
        token = Badge.generate_token()
        Badge.hdr["Authorization"] = "oauth " + token["access_token"]
    @staticmethod
    def generate_token(base_url):
        global CRED
        global get_New_Token
        print(base_url.split('primeapi')[0])
        url = base_url.split('primeapi')[0]
        access_token = get_New_Token(url,CRED)
        Badge.hdr["Authorization"] = "oauth " + access_token["access_token"]

    @classmethod
    def get_badge_response_body(cls):
        print(Badge.URL)
        res = get(Badge.URL, params=Badge.query, headers=Badge.hdr)
        return res.json()


    @classmethod
    def get_badge_response_code(cls):
        res = get(Badge.URL, params=Badge.query, headers=Badge.hdr)
        return res.status_code


    def pagination_badge(self,reversed,env,pagelimit,offset):
        global enviroment
        fail=False
        test=False
        has_next=True
        total_records_obtained=0


        Badge.generate_token(enviroment[env])
        self.set_url=enviroment[env]

        if not reversed:
            self.set_query={"offset":str(offset),"limit":str(pagelimit),"sort":"name"}
        else:
            self.set_query={"offset":str(offset),"limit":str(pagelimit),"sort":"-name"}

        while not fail and has_next:
            try:
                res=Badge.get_badge_response_body()
                total_records_obtained=total_records_obtained+len(res["data"])
                if res["links"]["next"]:
                   print(res["links"]["next"].split('?')[1].split('&')[0])
                   Badge.query["page[offset]"]=res["links"]["next"].split('?')[1].split('&')[0].split('=')[1]
                   has_next=True
                if len(res["data"])==pagelimit and has_next:
                    if total_records_obtained>self.no:
                        fail=True
                        test=False
                    else:
                        fail=False
                elif len(res["data"])<pagelimit and not has_next:
                    if total_records_obtained<self.no:
                        fail=True
                        test=False
                    elif total_records_obtained==self.no:
                        fail=True
                        test=True
                    elif total_records_obtained>self.no:
                        fail=True
                        test=False
                elif len(res["data"])>pagelimit:
                        fail=True
                        test=False
                elif len(res["data"])<pagelimit and has_next:
                        fail=True
                        test=False
                elif len(res["data"])==pagelimit and not has_next:
                        if total_records_obtained==self.no:
                            test=True
                        else:
                            test=False
                            fail=True
            except KeyError as k:
                if total_records_obtained==self.no:
                    fail=True
                    test=True
                    has_next=False
                else:
                    fail=True
                    test=False
                    has_next=False

        return test



if __name__ == "__main__":
    global enviroment
    print(enviroment[sys.argv[1]])
    Badge.generate_token(enviroment[sys.argv[1]])
    badge = Badge(30)
    badge.set_url = enviroment[sys.argv[1]]
    print(badge.set_url)
    badge.set_query ={"offset": 0, "limit": 10, "sort": "name"}
    print(Badge.get_badge_response_body())
    print(badge.pagination_badge(True,sys.argv[1],2,0))
    print(badge.pagination_badge(False,sys.argv[1],2,0))



















