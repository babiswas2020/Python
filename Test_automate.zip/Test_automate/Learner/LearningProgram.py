from url_generator import *
from requests import get, post
import sys


class LearningProgram:
    query = {"filter.loTypes":"learningProgram","filter.catalogIds":'',"page[limit]": 10,"filter.learnerState":'', "sort": "name", "ids": '',"include":'',"page[cursor]":''}
    endpoint ="learningObjects"
    SORT = ["name", "-name","date","-date","effectiveness"]
    LEARNER_STATE=["enrolled","started","completed","notenrolled"]
    hdr = {"Authorization": ''}
    INCLUDE=[]
    URL = ""
    URL_ID = ""

    def __init__(self, no):
        self.no = no

    @property
    def set_no(self):
        return self.no

    @set_no.setter
    def set_no(self,no):
        self.no=no
    
    @property
    def set_url(self):
        return LearningProgram.URL

    
    @set_url.setter
    def set_url(self, base_url):
        LearningProgram.URL = base_url + LearningProgram.endpoint

        
    @property
    def set_url_id(self):
        return LearningProgram.URL_ID

        
    @set_url_id.setter
    def set_url_id(self,course_id):
        LearningProgram.URL_ID = LearningProgram.URL + "/" + str(course_id)

        
    @property
    def set_query(self):
        return LearningProgram.query

        
    @set_query.setter
    def set_query(self, key):
        LearningProgram.query["filter.loTypes"] = str(key["loTypes"])
        LearningProgram.query["page[limit]"] = str(key["limit"])
        LearningProgram.query["filter.learnerState"] = str(key["learnerstate"])

        if key["sort"]=="name":
            LearningProgram.query["sort"] ="name"
        elif key["sort"]=="-name":
            LearningProgram.query["sort"] ="-name"
        elif key["sort"]=="date":
            LearningProgram.query["sort"]="date"
        elif key["sort"]=="-date":
            LearningProgram.query["sort"]="-date"
        elif key["sort"]=="effectiveness":
            LearningProgram.query["sort"]="effectiveness"
        else:
            LearningProgram.query["sort"]="name"

        try:
            if key["catalogid"]:
                 LearningProgram.query["filter.catalogIds"] = key["catalogid"]
        except Exception as e:
            if "filter.catalogIds" in LearningProgram.query:
                    del LearningProgram.query["filter.catalogIds"]

        try:
            if key["include"]:
                 LearningProgram.query["include"] = key["include"]
        except Exception as e:
            if "include" in LearningProgram.query:
                 del LearningProgram.query["include"]

        try:
            if key["cursor"]:
                 LearningProgram.query["page[cursor]"] = key["cursor"]
        except Exception as e:
            if "page[cursor]" in LearningProgram.query:
                 del LearningProgram.query["page[cursor]"]


        try:
            if key["ids"]:
                 LearningProgram.query["ids"] ="%2C".join(key["ids"])
        except Exception as e:
            if "ids" in LearningProgram.query:
                 del LearningProgram.query["ids"]


        try:
            if key["tag"]:
                 LearningProgram.query["filter.tagName"] = key["tag"]
        except Exception as e:
            if "filter.tagName" in LearningProgram.query:
                 del LearningProgram.query["filter.tagName"]

            
    @property
    def set_header(self):
        return LearningProgram.hdr


    @set_header.setter
    def set_header(self, *args):
        token = LearningProgram.generate_token()
        LearningProgram.hdr["Authorization"] = "oauth " + token["access_token"]

        
    @staticmethod
    def generate_token(base_url):
        global CRED
        global get_New_Token
        print(base_url.split('primeapi')[0])
        url = base_url.split('primeapi')[0]
        access_token = get_New_Token(url,CRED)
        LearningProgram.hdr["Authorization"] = "oauth " + access_token["access_token"]

    @classmethod
    def get_learningprogram_response_body(cls):
        print(LearningProgram.URL)
        res = get(LearningProgram.URL, params=LearningProgram.query, headers=LearningProgram.hdr)
        return res.json()


    @classmethod
    def get_learningprogram_response_code(cls):
        res = get(LearningProgram.URL, params=LearningProgram.query, headers=LearningProgram.hdr)
        return res.status_code


    def pagination_LP(self,query,env,pagelimit,learner_state,**kwargs):
        global enviroment
        fail=False
        test=False
        has_next=True
        total_records_obtained=0


        LearningProgram.generate_token(enviroment[env])
        self.set_url=enviroment[env]

        if query=="name":
            self.set_query={"loTypes":"course","limit":str(pagelimit),"sort":"-name","learnerstate":learner_state}
        elif query=="-name":
            self.set_query={"loTypes":"course","limit":str(pagelimit),"sort":"-name","learnerstate":learner_state}
        elif query=="date":
            self.set_query={"loTypes":"course","limit":str(pagelimit),"sort":"date","learnerstate":learner_state}
        elif query=="-date":
            self.set_query={"loTypes":"course","limit":str(pagelimit),"sort":"-date","learnerstate":learner_state}
        elif query=="effectiveness":
            self.set_query={"loTypes":"course","limit":str(pagelimit),"sort":"effectiveness","learnerstate":learner_state}

        if "catalogid" in kwargs:
           LearningProgram.query["filter.catalogIds"]=kwargs["catalogid"]
        if "include" in kwargs:
           LearningProgram.query["include"]=kwargs["include"]
        if "ids" in kwargs:
           LearningProgram.query["filter.catalogIds"]="%2C".join(kwargs["ids"])
        

        while not fail and has_next:
            try:
                res=LearningProgram.get_learningprogram_response_body()
                total_records_obtained=total_records_obtained+len(res["data"])
                print(res)
                if res["links"]["next"]:
                   print(res["links"]["next"].split('?')[1].split('&')[0])
                   LearningProgram.query["page[cursor]"]=res["links"]["next"].split('?')[1].split('&')[-1].split('=')[1]
                   has_next=True
                if len(res["data"])==pagelimit and has_next:
                    if total_records_obtained>self.no:
                        fail=True
                        test=False
                    else:
                        fail=False
                elif len(res["data"])<pagelimit and not has_next:
                    if total_records_obtained<self.no:
                        fail=True
                        test=False
                    elif total_records_obtained==self.no:
                        fail=True
                        test=True
                    elif total_records_obtained>self.no:
                        fail=True
                        test=False
                elif len(res["data"])>pagelimit:
                        fail=True
                        test=False
                elif len(res["data"])<pagelimit and has_next:
                        fail=True
                        test=False
                elif len(res["data"])==pagelimit and not has_next:
                        if total_records_obtained==self.no:
                            test=True
                        else:
                            test=False
                            fail=True
            except KeyError as k:
                 if total_records_obtained==self.no:
                    fail=True
                    test=True
                    has_next=False
                 else:
                    fail=True
                    test=False
                    has_next=False

        return test


if __name__ == "__main__":
    global enviroment
    print(enviroment[sys.argv[1]])
    LearningProgram.generate_token(enviroment[sys.argv[1]])
    learningprogram = LearningProgram(2)
    learningprogram.set_url = enviroment[sys.argv[1]]
    learningprogram.set_query = {"loTypes":"learningProgram","limit":10,"sort":"-name","learnerstate":"enrolled"}
    print(learningprogram.get_learningprogram_response_body())
    print(learningprogram.pagination_LP("name",sys.argv[1],2,"enrolled"))
    print(learningprogram.pagination_LP("-name",sys.argv[1],2,"enrolled"))