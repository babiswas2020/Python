class Node:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None


def height(root):
    queue = []
    len_queue = 0
    count = 0
    if root:
        queue.append(root)
    else:
        return count
    while queue:
        len_queue = len(queue)
        if not len_queue:
            return count
        else:
            count = count + 1
        while len_queue:
            s = queue.pop(0)
            if s.left:
                queue.append(s.left)
            if s.right:
                queue.append(s.right)
            len_queue = len_queue - 1
    return count


def diameter(root):
    height_left, height_right, d_left, d_right = 0, 0, 0, 0
    if not root:
        return 0
    else:
        if root.left:
            height_left = height(root.left)
        if root.right:
            height_right = height(root.right)
        if root.left:
            d_left = diameter(root.left)
        if root.right:
            d_right = diameter(root.right)
        return max(height_left + height_right + 1, max(d_left, d_right))


if __name__ == "__main__":
    node = Node(21)
    node.left = Node(32)
    node.right = Node(42)
    node.left.left = Node(4)
    node.left.right = Node(5)
    print(height(node))



