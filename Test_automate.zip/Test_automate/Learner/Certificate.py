from url_generator import *
from requests import get, post
import sys


class Certificate:
    query = {"filter.loTypes":"course","filter.catalogIds":'',"page[limit]": 10,"filter.learnerState":'', "sort": "name", "ids": '',"include":'',"page[cursor]":''}
    endpoint ="learningObjects"
    SORT = ["name", "-name","date","-date","effectiveness"]
    LEARNER_STATE=["enrolled","started","completed","notenrolled"]
    hdr = {"Authorization": ''}
    INCLUDE=[]
    URL = ""
    URL_ID = ""

    def __init__(self, no):
        self.no = no

    
    @property
    def set_url(self):
        return Certificate.URL

    
    @set_url.setter
    def set_url(self, base_url):
        Certificate.URL = base_url + Certificate.endpoint

        
    @property
    def set_url_id(self):
        return Certificate.URL_ID

        
    @set_url_id.setter
    def set_url_id(self,course_id):
        Certificate.URL_ID = Certificate.URL + "/" + str(course_id)

        
    @property
    def set_query(self):
        return Certificate.query

        
    @set_query.setter
    def set_query(self, key):
        Certificate.query["filter.loTypes"] = str(key["loTypes"])
        Certificate.query["page[limit]"] = str(key["limit"])
        Certificate.query["filter.learnerState"] = str(key["learnerstate"])

        if key["sort"]=="name":
            Certificate.query["sort"] ="name"
        elif key["sort"]=="-name":
            Certificate.query["sort"] ="-name"
        elif key["sort"]=="date":
            Certificate.query["sort"]="date"
        elif key["sort"]=="-date":
            Certificate.query["sort"]="-date"
        elif key["sort"]=="effectiveness":
            Certificate.query["sort"]="effectiveness"
        else:
            Certificate.query["sort"]="name"

        try:
            if key["catalogid"]:
                 Certificate.query["filter.catalogIds"] = key["catalogid"]
        except Exception as e:
            if "filter.catalogIds" in Certificate.query:
                    del Certificate.query["filter.catalogIds"]

        try:
            if key["include"]:
                 Certificate.query["include"] = key["include"]
        except Exception as e:
            if "include" in Certificate.query:
                 del Certificate.query["include"]

        try:
            if key["cursor"]:
                 Certificate.query["page[cursor]"] = key["cursor"]
        except Exception as e:
            if "page[cursor]" in Certificate.query:
                 del Certificate.query["page[cursor]"]


        try:
            if key["ids"]:
                 Certificate.query["ids"] ="%2C".join(key["ids"])
        except Exception as e:
            if "ids" in Certificate.query:
                 del Certificate.query["ids"]


        try:
            if key["tag"]:
                 Certificate.query["filter.tagName"] = key["tag"]
        except Exception as e:
            if "filter.tagName" in Certificate.query:
                 del Certificate.query["filter.tagName"]

            
    @property
    def set_header(self):
        return Certificate.hdr


    @set_header.setter
    def set_header(self, *args):
        token = Certificate.generate_token()
        Certificate.hdr["Authorization"] = "oauth " + token["access_token"]

        
    @staticmethod
    def generate_token(base_url):
        global CRED
        global get_New_Token
        print(base_url.split('primeapi')[0])
        url = base_url.split('primeapi')[0]
        access_token = get_New_Token(url,CRED)
        Certificate.hdr["Authorization"] = "oauth " + access_token["access_token"]

    @classmethod
    def get_certificate_response_body(cls):
        print(Certificate.URL)
        res = get(Certificate.URL, params=Certificate.query, headers=Certificate.hdr)
        return res.json()


    @classmethod
    def get_certificate_response_code(cls):
        res = get(Certificate.URL, params=Certificate.query, headers=Certificate.hdr)
        return res.status_code


    def pagination_Certificate(self,query,env,pagelimit,learner_state,**kwargs):
        global enviroment
        fail=False
        test=False
        has_next=True
        total_records_obtained=0


        Certificate.generate_token(enviroment[env])
        self.set_url=enviroment[env]

        if query=="name":
            self.set_query={"loTypes":"course","limit":str(pagelimit),"sort":"-name","learnerstate":learner_state}
        elif query=="-name":
            self.set_query={"loTypes":"course","limit":str(pagelimit),"sort":"-name","learnerstate":learner_state}
        elif query=="date":
            self.set_query={"loTypes":"course","limit":str(pagelimit),"sort":"date","learnerstate":learner_state}
        elif query=="-date":
            self.set_query={"loTypes":"course","limit":str(pagelimit),"sort":"-date","learnerstate":learner_state}
        elif query=="effectiveness":
            self.set_query={"loTypes":"course","limit":str(pagelimit),"sort":"effectiveness","learnerstate":learner_state}

        if "catalogid" in kwargs:
           Certificate.query["filter.catalogIds"]=kwargs["catalogid"]
        if "include" in kwargs:
           Certificate.query["include"]=kwargs["include"]
        if "ids" in kwargs:
           Certificate.query["filter.catalogIds"]="%2C".join(kwargs["ids"])
        

        while not fail and has_next:
            try:
                res=Certificate.get_certificate_response_body()
                total_records_obtained=total_records_obtained+len(res["data"])
                print(res)
                if res["links"]["next"]:
                   print(res["links"]["next"].split('?')[1].split('&')[0])
                   Certificate.query["page[cursor]"]=res["links"]["next"].split('?')[1].split('&')[-1].split('=')[1]
                   has_next=True
                if len(res["data"])==pagelimit and has_next:
                    if total_records_obtained>self.no:
                        fail=True
                        test=False
                    else:
                        fail=False
                elif len(res["data"])<pagelimit and not has_next:
                    if total_records_obtained<self.no:
                        fail=True
                        test=False
                    elif total_records_obtained==self.no:
                        fail=True
                        test=True
                    elif total_records_obtained>self.no:
                        fail=True
                        test=False
                elif len(res["data"])>pagelimit:
                        fail=True
                        test=False
                elif len(res["data"])<pagelimit and has_next:
                        fail=True
                        test=False
                elif len(res["data"])==pagelimit and not has_next:
                        if total_records_obtained==self.no:
                            test=True
                        else:
                            test=False
                            fail=True
            except KeyError as k:
                 if total_records_obtained==self.no:
                    fail=True
                    test=True
                    has_next=False
                 else:
                    fail=True
                    test=False
                    has_next=False

        return test


if __name__ == "__main__":
    global enviroment
    print(enviroment[sys.argv[1]])
    Certificate.generate_token(enviroment[sys.argv[1]])
    certificate = Certificate(2)
    certificate.set_url = enviroment[sys.argv[1]]
    certificate.set_query = {"loTypes":"course","limit":10,"sort":"-name","learnerstate":"enrolled"}
    print(certificate.get_certificate_response_body())
    print(certificate.pagination_Certificate("name",sys.argv[1],2,"enrolled"))
    print(certificate.pagination_Certificate("-name",sys.argv[1],2,"enrolled"))