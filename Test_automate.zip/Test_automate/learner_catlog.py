from utility import *
from time import time
import json

@get_request
def get_catalog_lo(*args):
    return args[1]

@get_request
def get_enrollment_id(*args):
    return args[1]


@Report_generate
def test_lo_catalog(testcase,state,catalogid,count):
    enrollment=[]
    try:
       data=get_data()
       data.clear()
       data["page[limit]"]=10
       data["page[cursor]"]=''
       data["filter.catalogIds"]=catalogid
       data["filter.learnerState"]=state
       while True:
          res=get_catalog_lo("learningObjects")
          for obj in res["data"]:
             enrollment.append(obj["relationships"]["enrollment"]["data"]["id"])
          if "next" in res["links"]:
              cursor=res["links"]["next"].split('&')[-1].split('=')[-1]
              data["page[cursor]"]=cursor
          else:
              break 
       for id in  enrollment: 
           str1="enrollments/"+str(id)
           resp=get_enrollment_id(str1)
           if resp["data"]["attributes"]["state"]!=state.upper():
              return False
       if len(enrollment)!=count:
           return False
       return True           
    except Exception as e:
       return False


@Report_generate
def test_lo_catalog_started_completed(testcase,catalogid,count):
    enrollment=[]
    test=False
    try:
       data=get_data()
       data.clear()
       data["page[limit]"]=10
       data["page[cursor]"]=''
       data["filter.catalogIds"]=catalogid
       data["filter.learnerState"]="completed,started"
       while True:
          res=get_catalog_lo("learningObjects")
          for obj in res["data"]:
             enrollment.append(obj["relationships"]["enrollment"]["data"]["id"])
          if "next" in res["links"]:
              cursor=res["links"]["next"].split('&')[-1].split('=')[-1]
              data["page[cursor]"]=cursor
          else:
              break
       for id in  enrollment:
           str1="enrollments/"+str(id)
           resp=get_enrollment_id(str1)
           if resp["data"]["attributes"]["state"]=="COMPLETED" or resp["data"]["attributes"]["state"]=="STARTED":
               test=True
           else:
               test=False
               return False
       if len(enrollment)!=count:
           return False
       return test
    except Exception as e:
       return False


@Report_generate
def test_lo_catalog_enrolled_completed(testcase,catalogid,count):
    enrollment=[]
    test=False
    try:
       data=get_data()
       data.clear()
       data["page[limit]"]=10
       data["page[cursor]"]=''
       data["filter.catalogIds"]=catalogid
       data["filter.learnerState"]="completed,enrolled"
       while True:
          res=get_catalog_lo("learningObjects")
          for obj in res["data"]:
             enrollment.append(obj["relationships"]["enrollment"]["data"]["id"])
          if "next" in res["links"]:
              cursor=res["links"]["next"].split('&')[-1].split('=')[-1]
              data["page[cursor]"]=cursor
          else:
              break
       for id in  enrollment:
           str1="enrollments/"+str(id)
           resp=get_enrollment_id(str1)
           if resp["data"]["attributes"]["state"]=="COMPLETED" or resp["data"]["attributes"]["state"]=="ENROLLED":
               test=True
           else:
               test=False
               return False
       if len(enrollment)!=count:
           return False
       return test
    except Exception as e:
       return False


@Report_generate
def test_lo_catalog_enrolled_started(testcase,catalogid,count):
    enrollment=[]
    test=False
    try:
       data=get_data()
       data.clear()
       data["page[limit]"]=10
       data["page[cursor]"]=''
       data["filter.catalogIds"]=catalogid
       data["filter.learnerState"]="enrolled,started"
       while True:
          res=get_catalog_lo("learningObjects")
          for obj in res["data"]:
             enrollment.append(obj["relationships"]["enrollment"]["data"]["id"])
          if "next" in res["links"]:
              cursor=res["links"]["next"].split('&')[-1].split('=')[-1]
              data["page[cursor]"]=cursor
          else:
              break
       for id in  enrollment:
           str1="enrollments/"+str(id)
           resp=get_enrollment_id(str1)
           if resp["data"]["attributes"]["state"]=="STARTED" or resp["data"]["attributes"]["state"]=="ENROLLED":
               test=True
           else:
               test=False
               return False
       if len(enrollment)!=count:
           return False
       return test
    except Exception as e:
       return False


@Report_generate
def test_lo_catalog_enrolled_started_completed(testcase,catalogid,count):
    enrollment=[]
    test=False
    try:
       data=get_data()
       data.clear()
       data["page[limit]"]=10
       data["page[cursor]"]=''
       data["filter.catalogIds"]=catalogid
       data["filter.learnerState"]="started,completed,enrolled"
       while True:
          res=get_catalog_lo("learningObjects")
          for obj in res["data"]:
             enrollment.append(obj["relationships"]["enrollment"]["data"]["id"])
          if "next" in res["links"]:
              cursor=res["links"]["next"].split('&')[-1].split('=')[-1]
              data["page[cursor]"]=cursor
          else:
              break
       for id in  enrollment:
           str1="enrollments/"+str(id)
           resp=get_enrollment_id(str1)
           if resp["data"]["attributes"]["state"]=="STARTED" or resp["data"]["attributes"]["state"]=="ENROLLED" or resp["data"]["attributes"]["state"]=="COMPLETED":
               test=True
           else:
               test=False
               return False
       if len(enrollment)!=count:
           return False
       return test
    except Exception as e:
       return False

@Report_generate
def test_lo_catalog_notenrolled(testcase,state,catalogid,count):
    enrollment=[]
    try:
       data=get_data()
       data.clear()
       data["page[limit]"]=10
       data["page[cursor]"]=''
       data["filter.catalogIds"]=catalogid
       data["filter.learnerState"]=state
       while True:
          res=get_catalog_lo("learningObjects")
          for obj in res["data"]:
             if "enrollment" not in obj["relationships"].keys():
                enrollment.append(obj["id"])
             else:
                return False
          if "next" in res["links"]:
              cursor=res["links"]["next"].split('&')[-1].split('=')[-1]
              data["page[cursor]"]=cursor
          else:
              break 
       if len(enrollment)!=count:
           return False
       return True           
    except Exception as e:
       return False

if __name__=="__main__":
   Auto_init("learnerstate.csv")
   Env_init("2aa97068-92dc-4741-8c57-ce44e777eba7","afd4cfd3-ae00-45b2-bb48-1ded68d102e3","3901162ffb2c30680433666086f82c82")
   test_lo_catalog("Test the completed state of the lo related to catalog","completed",13478,15)
   test_lo_catalog("Test the enrolled state of the lo related to catalog","enrolled",13478,12)
   test_lo_catalog("Test the enrolled state of the lo related to catalog","started",13478,7)
   test_lo_catalog_started_completed("Test the started and completed state of the lo related to catalog",13478,22)
   test_lo_catalog_enrolled_completed("Test the completed and enrolled state of the learner",13478,27)
   test_lo_catalog_enrolled_started("Test the enrolled and started status",13478,19)
   test_lo_catalog_enrolled_started_completed("Test the enrolled ,started,completed state of the learner",13478,34)
   test_lo_catalog_notenrolled("Test the not enrolled status of the learner","notenrolled",13478,12)
   Auto_close()


    





