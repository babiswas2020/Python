from utility import *

@get_request
def get_skill(*args):
    return args[1],args[2]

@Report_generate
def test_skill_include_level_skill(Testcase,skill_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "levels.skill"
    data["ids"] = str(skill_id)
    try:
        req,status = get_skill("skills")
        if status!=200:
           raise Exception
    except Exception as e:
        return False
    object_id = []
    try:
        for obj in req["included"]:
            object_id.append(obj["id"])
        for obj in args:
            if obj not in object_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_skill_include_level_skill_id(Testcase,skill_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "levels.skill"
    try:
        str1="skills/"+str(skill_id)
        req,status = get_skill(str1)
        if status!=200:
           raise Exception
    except Exception as e:
        return False
    object_id = []
    try:
        for obj in req["included"]:
            object_id.append(obj["id"])
        for obj in args:
            if obj not in object_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_skill_include_level_badge(Testcase,skill_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "levels.badge"
    data["ids"] = str(skill_id)
    try:
        req,status = get_skill("skills")
        if status!=200:
           raise Exception
    except Exception as e:
        return False
    object_id = []
    try:
        for obj in req["included"]:
            object_id.append(obj["id"])
        for obj in args:
            if obj not in object_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_skill_include_level_badge_id(Testcase,skill_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "levels.badge"
    try:
        str1="skills/"+str(skill_id)
        req,status = get_skill(str1)
        if status!=200:
           raise Exception
    except Exception as e:
        return False
    object_id = []
    try:
        for obj in req["included"]:
            object_id.append(obj["id"])
        for obj in args:
            if obj not in object_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_skill_include_level_verify_badge_object(Testcase,skill_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "levels.badge"
    data["ids"] = str(skill_id)
    try:
        req,status = get_skill("skills")
        if status!=200:
           raise Exception
    except Exception as e:
        return False
    badge_id = []
    try:
        for obj in req["included"]:
            if obj["type"]=="badge":
               badge_id.append(obj["id"])

        for obj in args:
            if obj not in badge_id:
                return False
        return True
    except Exception as e:
        return False



@Report_generate
def test_skill_include_level_verify_level_object(Testcase,skill_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "levels.skill"
    data["ids"] = str(skill_id)
    try:
        req,status = get_skill("skills")
        if status!=200:
           raise Exception
    except Exception as e:
        return False
    level_id = []
    try:
        for obj in req["included"]:
            if obj["type"]=="skillLevel":
               level_id.append(obj["id"])

        for obj in args:
            if obj not in level_id:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_skill_include_level_verify_skilllevel_attributes(Testcase,skill_id,level_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "levels.skill"
    data["ids"] = str(skill_id)
    try:
        req,status = get_skill("skills")
        if status!=200:
           raise Exception
    except Exception as e:
        return False
    try:
        for obj in req["included"]:
            if obj["type"]=="skillLevel" and obj["id"]==level_id:
               if obj["attributes"]["level"]==args[0] and obj["attributes"]["maxCredits"]==args[1] and obj["attributes"]["name"]==args[2]:
                            return True
               else:
                            return False
    except Exception as e:
        return False


if __name__=="__main__":
    Auto_init("Skill_include.csv")
    Env_init("d2962f50-2fc5-44ff-b121-f1a66fc28bf8", "2de3af33-6fb5-4b3e-9625-49b605996901","239fab80cecf817be675909d46777cc0")
    test_skill_include_level_skill("Test the objects in include array for include=levels.skill",43941,"43941_1","43941_3","43941_2")
    test_skill_include_level_badge("Verify the objects in include array for the skill id 44018",44018,"7382","7384","44018_1","44018_2")
    test_skill_include_level_verify_badge_object("Test the badge objects in the include array",44018,"7382","7384")
    test_skill_include_level_verify_level_object("Test the level objects in the include array",44018,"44018_1","44018_2")
    test_skill_include_level_verify_skilllevel_attributes("Test the level objects attributes",44018,"44018_1","1",10.1,"Level 1")
    test_skill_include_level_verify_skilllevel_attributes("Test the level objects attributes",44018,"44018_2","2",20,"Level 2")
    test_skill_include_level_skill_id("Verify the objects in include array for the skill by id",43941,"43941_1","43941_3","43941_2")
    test_skill_include_level_badge_id("Verify the badge objects in include array for the skill by id",44018,"7382","7384","44018_1","44018_2")
    Auto_close()