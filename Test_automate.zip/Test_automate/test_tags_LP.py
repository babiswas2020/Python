from utility import *
from time import time
import json

#taga@faga.com
#Learner#12

@get_request
def get_request(*args):
    return args[1],args[2]

@Report_generate
def test_tag_LP(testcase,tag_value,*args):
    data = get_data()
    data.clear()
    data["filter.tagName"] = tag_value
    data["page[offset]"] =0
    data["page[limit]"]=10
    data["filter.loTypes"] = "learningProgram"
    try:
      url="learningObjects"
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
       cid=[]
       for obj in res["data"]:
          if obj["attributes"]["tags"][0]!=tag_value:
               return False
          cid.append(obj["id"])
       for i in args:
          if i not in cid:
            return False
       if len(cid)!=5:
          return False
       return True
    except Exception as e:
        return False


@Report_generate
def test_2tag_Course(testcase,tag_value1,tag_value2,*args):
    data = get_data()
    data.clear()
    data["filter.tagName"] = tag_value1+","+tag_value2
    data["filter.loTypes"] ="learningProgram"
    data["page[limit]"]=10
    try:
      url="learningObjects"
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
       cid=[]
       for obj in res["data"]:
          if obj["attributes"]["tags"][0]==tag_value1 or obj["attributes"]["tags"][0]==tag_value2:
               pass
          else:
              return False
          cid.append(obj["id"])
       for i in args:
          if i not in cid:
            return False
       if len(cid)!=10:
          return False
       return True
    except Exception as e:
        return False






if __name__=="__main__":
   Auto_init("Tag_LP.csv")
   Env_init("7a5fca40-1013-4166-bb92-cee58a43a980","54cda52b-f078-42e3-8a75-ad3b605166f7","31cafab8def2491b6bd0395dd72974c8")
   test_tag_LP("Test the LP1 tag Learning Program in prime account","LP1","learningProgram:40508","learningProgram:40510","learningProgram:40507","learningProgram:40506","learningProgram:40509")
   test_tag_LP("Test the LP2 tag Learning Program in prime account","LP2","learningProgram:40514","learningProgram:40515","learningProgram:40511","learningProgram:40513","learningProgram:40512")
   test_tag_LP("Test the LP3 tag Learning Program in prime account","LP3","learningProgram:40516","learningProgram:40519","learningProgram:40517","learningProgram:40518","learningProgram:40520")
   test_tag_LP("Test the LP4 tag Learning Program in prime account","LP4","learningProgram:40523","learningProgram:40524","learningProgram:40525","learningProgram:40521","learningProgram:40522")
   test_2tag_Course("Test the LP1/LP2 tags associated with LP","LP1","LP2","learningProgram:40508","learningProgram:40510","learningProgram:40507","learningProgram:40506","learningProgram:40509","learningProgram:40514","learningProgram:40511","learningProgram:40513","learningProgram:40515","learningProgram:40512")
   test_2tag_Course("Test the LP2/LP3 tags associated with LP","LP2","LP3","learningProgram:40514","learningProgram:40511","learningProgram:40513","learningProgram:40515","learningProgram:40512","learningProgram:40516","learningProgram:40519","learningProgram:40517","learningProgram:40518","learningProgram:40520")
   test_2tag_Course("Test the LP3/LP4 tags associated with LP","LP3","LP4","learningProgram:40523","learningProgram:40525","learningProgram:40524","learningProgram:40516","learningProgram:40518","learningProgram:40520","learningProgram:40519","learningProgram:40517","learningProgram:40521","learningProgram:40522")
   Auto_close()
