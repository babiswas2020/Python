from utility import *
from time import time
import json

#bapan12q@gmail.com
#Learner#12

@get_request
def get_request(*args):
    return args[1],args[2]

@Report_generate
def test_learnerbadge_include(testcase,userid,userbadgeid,*args):
    data = get_data()
    data.clear()
    data["include"] = "model.enrollment.loResourceGrades"
    data["ids"] =userbadgeid 
    try:
      url="users/"+str(userid)+"/userBadges"
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
       include=[]
       for obj in res["included"]:
          include.append(obj["id"])
       for id in args:
          if id not in include:
             return False
       return True
    except Exception as e:
        return False

@Report_generate
def test_learnerbadge_include_id(testcase,userbadgeid,*args):
    data = get_data()
    data.clear()
    data["include"] = "model.enrollment.loResourceGrades"
    data["ids"] =userbadgeid 
    try:
      url="users/"+userbadgeid.split('_')[0]+"/userBadges/"+userbadgeid
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
       include=[]
       for obj in res["included"]:
          include.append(obj["id"])
       for id in args:
          if id not in include:
             return False
       return True
    except Exception as e:
        return False

@Report_generate
def test_learnerbadge_enrollment_model(testcase,userid,userbadgeid,*args):
    data = get_data()
    data.clear()
    data["include"] = "model.enrollment.loResourceGrades"
    data["ids"] =userbadgeid 
    try:
      url="users/"+str(userid)+"/userBadges"
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
      for obj in res["included"]:
          if obj["type"]=="learningObjectInstanceEnrollment":
             if obj["attributes"]["state"]==args[3] and obj["attributes"]["progressPercent"]==args[0] and obj["attributes"]["dateStarted"]==args[1] and obj["attributes"]["dateCompleted"]==args[2]:
                  return True
             else:
                  return False
      return False
    except Exception as e:
        return False

@Report_generate
def test_learnerbadge_enrollment_model_id(testcase,userbadgeid,*args):
    data = get_data()
    data.clear()
    data["include"] = "model.enrollment.loResourceGrades"
    try:
      url="users/"+userbadgeid.split('_')[0]+"/userBadges/"+userbadgeid
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
      for obj in res["included"]:
          if obj["type"]=="learningObjectInstanceEnrollment":
             if obj["attributes"]["state"]==args[3] and obj["attributes"]["progressPercent"]==args[0] and obj["attributes"]["dateStarted"]==args[1] and obj["attributes"]["dateCompleted"]==args[2]:
                  return True
             else:
                  return False
      return False
    except Exception as e:
        return False


@Report_generate
def test_learnerbadge_loresourcegrade_model(testcase,userid,userbadgeid,*args):
    data = get_data()
    data.clear()
    data["include"] = "model.enrollment.loResourceGrades"
    data["ids"] =userbadgeid 
    try:
      url="users/"+str(userid)+"/userBadges"
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
       for obj in res["included"]:
           if obj["type"]=="learningObjectResourceGrade":
               if obj["attributes"]["dateCompleted"]==args[0] and obj["attributes"]["dateStarted"]==args[1] and obj["attributes"]["dateSuccess"]==args[2] and obj["attributes"]["hasPassed"]==args[3]:
                    return True
               else:
                   return False
       return False
    except Exception as e:
        return False


@Report_generate
def test_learnerbadge_course_model(testcase,userid,userbadgeid,*args):
    data = get_data()
    data.clear()
    data["include"] = "model.enrollment.loResourceGrades"
    data["ids"] =userbadgeid 
    try:
      url="users/"+str(userid)+"/userBadges"
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
       include=[]
       for obj in res["included"]:
          if obj["type"]=="learningObject":
             if obj["relationships"]["enrollment"]["data"]["id"]==args[0]:
                   return True
             else:
                   return False
       return False
    except Exception as e:
        return False

@Report_generate
def test_learnerbadge_course_skill_model(testcase,userid,userbadgeid,*args):
    data = get_data()
    data.clear()
    data["include"] = "model.skills"
    data["ids"] =userbadgeid 
    try:
      url="users/"+str(userid)+"/userBadges"
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
       for obj in res["included"]:
          if obj["type"]=="learningObjectSkill":
             if obj["attributes"]["credits"]==args[0] and obj["relationships"]["skillLevel"]["data"]["id"]==args[1]:
                return True
             else:
                return False
       return False
    except Exception as e:
        return False


@Report_generate
def test_learnerbadge_badge_model_learner_include(testcase,userid,userbadgeid,*args):
    data = get_data()
    data.clear()
    data["include"] = "badge,learner,model"
    data["ids"] =userbadgeid 
    try:
      url="users/"+str(userid)+"/userBadges"
      res,status=get_request(url)
      if status!=200:
         raise Exception
    except Exception as e:
        return False
    try:
       include=[]
       for obj in res["included"]:
          include.append(obj["id"])
       for id in args:
          if id not in include:
             return False
       return True
    except Exception as e:
        return False




if __name__=="__main__":
   Auto_init("userbadge_course.csv")
   Env_init("7ce96f5a-2c07-4b93-a0e1-f025f8fa0aa9","5d084f8a-cdf3-480a-9dbb-5d24baa49da4","89900945b81d421f610f4ed2debd925f")
   test_learnerbadge_include("Test the objects in include array learner badge",7107207,"7107207_7306_COURSE_2037181","course:2037181_3717110_7107207","course:2037181","course:2037181_3717110_2675861_0_02d533dca36f4789a9487adf1ede76e4_4b2d71b302c545e9bae3893b0b9c32a2")
   test_learnerbadge_include_id("Test the objects in include array learner badge fetched by id","7107207_7306_COURSE_2037181","course:2037181_3717110_7107207","course:2037181","course:2037181_3717110_2675861_0_02d533dca36f4789a9487adf1ede76e4_4b2d71b302c545e9bae3893b0b9c32a2")
   test_learnerbadge_enrollment_model("Test the enollment object of the learner badge",7107207,"7107207_7306_COURSE_2037181",100,"2020-02-16T17:51:00.000Z","2020-02-16T17:51:00.000Z","COMPLETED")
   test_learnerbadge_enrollment_model_id("Test the enollment object of the learner badge fetch by id","7107207_7306_COURSE_2037181",100,"2020-02-16T17:51:00.000Z","2020-02-16T17:51:00.000Z","COMPLETED")
   test_learnerbadge_loresourcegrade_model("Test the loresourcegrade model of the userbadge",7107207,"7107207_7306_COURSE_2037181","2020-02-16T17:51:00.000Z","2020-02-16T17:51:00.000Z","2020-02-16T17:51:00.000Z",True)
   test_learnerbadge_course_model("Test the enrollment id associated with lo",7107207,"7107207_7306_COURSE_2037181","course:2037181_3717110_7107207")
   test_learnerbadge_course_skill_model("Test the skill model in include array",7107207,"7107207_7306_COURSE_2037181",10,"43182_1")
   test_learnerbadge_badge_model_learner_include("Test the learnerbadge model,learner,badge",7107207,"7107207_7306_COURSE_2037181","7306","course:2037181","7107207")
   Auto_close()
