from utility import *
from collections import defaultdict


@get_request
def get_lo(*args):
    return args[1]

@Report_generate
def test_LP_instance_enrollment(Testcase,LP_id,instance_id):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "enrollment"
    data["ids"] = str(LP_id)
    data["filter.loTypes"] = "learningProgram"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    try:
        if instance_id == req["data"][0]["relationships"]["enrollment"]["data"]["id"].split('_')[1]:
            print(req["data"][0]["relationships"]["enrollment"]["data"]["id"].split('_')[1])
            return True
        else:
            return False
    except Exception as e:
        return False


@Report_generate
def test_LP_sublo_enrollment(Testcase,LP_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "subLOs"
    data["ids"] = str(LP_id)
    data["filter.loTypes"] = "learningProgram"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    sublo_instance=[]
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObject":
                sublo_instance.append(obj["relationships"]["enrollment"]["data"]["id"].split('_')[1])
        print(sublo_instance)
        for i in args:
            if i not in sublo_instance:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_LP_tags(Testcase,LP_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "subLOs"
    data["ids"] = str(LP_id)
    data["filter.loTypes"] = "learningProgram"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    tags=[]
    try:
        for tag in req["data"][0]["attributes"]["tags"]:
           tags.append(tag)
        for i in args:
            if i not in tags:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_LP_sublo_enrollment_instance_name(Testcase,LP_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "subLOs.instances"
    data["ids"] = str(LP_id)
    data["filter.loTypes"] = "learningProgram"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    sublo_instance=[]
    subLO_instance_obj={}
    sublo_instance_name=[]
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObject":
                sublo_instance.append(obj["relationships"]["enrollment"]["data"]["id"].split('_')[1])
            if obj["type"]=="learningObjectInstance":
                subLO_instance_obj[obj["id"].split('_')[1]]=obj["attributes"]["localizedMetadata"][0]["name"]
        for obj in sublo_instance:
            if obj in subLO_instance_obj:
                sublo_instance_name.append(subLO_instance_obj[obj])
        for i in args:
            if i not in sublo_instance_name:
                return False
        return True
    except Exception as e:
        return False



@Report_generate
def test_completion_deadline_sublo(Testcase,LP_id,instance_id,deadline):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "subLOs.instances"
    data["ids"] = str(LP_id)
    data["filter.loTypes"] = "learningProgram"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    try:
        for obj in req["included"]:
            if obj["id"]==instance_id:
                if obj["attributes"]["completionDeadline"]==deadline:
                    return True
                else:
                    return False
        return False
    except Exception as e:
        return False


@Report_generate
def test_subloinstance_LP(Testcase,LP_id,instance_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "instances"
    data["ids"] = str(LP_id)
    data["filter.loTypes"] = "learningProgram"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    sublo_instance=[]
    try:
        for obj in req["included"]:
            if obj["id"]==instance_id:
                for i in obj["relationships"]["subLoInstances"]["data"]:
                    sublo_instance.append(i["id"])
        for obj in args:
            if obj not in sublo_instance:
                return False
        return True
    except Exception as e:
        return False



@Report_generate
def test_sublo_LP(Testcase,LP_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "subLOs"
    data["ids"] = str(LP_id)
    data["filter.loTypes"] = "learningProgram"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    sublo=[]
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObject":
                sublo.append(obj["id"])
        for obj in args:
            if obj not in sublo:
                return False
        return True
    except Exception as e:
        return False


@Report_generate
def test_sublo_order_LP(Testcase,LP_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "subLOs"
    data["ids"] = str(LP_id)
    data["filter.loTypes"] = "learningProgram"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    sublo=[]
    try:
        for obj in req["data"][0]["relationships"]["subLOs"]["data"]:
            sublo.append(obj["id"])
        if (sublo==list(args)) and (req["data"][0]["attributes"]["isSubLoOrderEnforced"]):
            return True
        return False
    except Exception as e:
        return False


@Report_generate
def test_course_skill_LP(Testcase,LP_id,*args):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "subLOs"
    data["ids"] = str(LP_id)
    data["filter.loTypes"] = "learningProgram"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    skill=[]
    try:
        for obj in req["data"][0]["relationships"]["skills"]["data"]:
            skill.append(obj["id"])
        if (skill==list(args)):
            return True
        return False
    except Exception as e:
        return False


@Report_generate
def test_skill_level_sublo(Testcase,LP_id,courseskilllevel):
    req = None
    data = get_data()
    data.clear()
    data["include"] = "skills"
    data["ids"] = str(LP_id)
    data["filter.loTypes"] = "learningProgram"
    try:
        req = get_lo("learningObjects")
    except Exception as e:
        return False
    courseskill=defaultdict(list)
    try:
        for obj in req["included"]:
            if obj["type"]=="learningObjectSkill":
                if obj["id"].split('_')[0] not in courseskill:
                          courseskill[obj["id"].split('_')[0]]=[]
                          courseskill[obj["id"].split('_')[0]].append(obj["relationships"]["skillLevel"]["data"]["id"])
                else:
                          courseskill[obj["id"].split('_')[0]].append(obj["relationships"]["skillLevel"]["data"]["id"])

        if courseskill==courseskilllevel:
            return True
        else:
            return False
    except Exception as e:
        return False


if __name__=="__main__":
    Auto_init("LP_Workflow.csv")
    Env_init("fff02ce8-c039-4006-9d0b-48e15adfd6fa", "c560f429-c463-4815-a697-798f11136a77","113fb50b4260ab62b43ba94b5c3003d1")
    ############ LP Instance enrollment and LP Course Mapping #################################################################
    test_LP_instance_enrollment("Test the LP instance enrolled to the learner","learningProgram:39641","46457")
    test_LP_sublo_enrollment("Test the sublo enrollment related to LP","learningProgram:39641","3700835","3700836")
    test_LP_tags("Test the tags associated with LP","learningProgram:39641","tag3","tag1","tag5")
    test_LP_sublo_enrollment_instance_name("Test the instance names of the sublo's in which the learner is enrolled to","learningProgram:39641","REWWWWW","MERRRRR")
    test_completion_deadline_sublo("Test the completion deadline for the sublo","learningProgram:39641","course:2021745_3700836","2027-11-17T18:29:59.000Z")
    test_subloinstance_LP("Test the sublo instance associated with LP instance","learningProgram:39641","learningProgram:39641_46457","course:2021746_3700835","course:2021745_3700836")
    test_sublo_LP("Test the sublo associated with the LP","learningProgram:39641","course:2021746","course:2021745")
    test_sublo_order_LP("Test if sublo order enforced in LP","learningProgram:39643","course:2021741","course:2021743","course:2021742")
    test_course_skill_LP("Test the course skills associated with the LP","learningProgram:39644","course:2021881_42398","course:2021881_42400","course:2021881_42401","course:2021881_42406","course:2021882_42398","course:2021882_42400")
    test_skill_level_sublo("Test the course skill skilllevel associated with the sublo","learningProgram:39644",{"course:2021881":["42398_2","42400_1","42401_2","42406_1"],"course:2021882":["42398_2","42400_1"]})
    Auto_close()